import React, { useState } from 'react';
import LoginScreen from './screens/LoginScreen';
import CarListScreen from './screens/CarListScreen';

export default function App() {
  const [token, setToken] = useState(null);
  const [carros, setCarros] = useState([]);

  return token ? (
    <CarListScreen token={token} carros={carros} setCarros={setCarros} />
  ) : (
    <LoginScreen setToken={setToken} setCarros={setCarros} />
  );
}
