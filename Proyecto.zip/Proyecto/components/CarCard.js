import React from 'react';
import { View, Text, Image } from 'react-native';
import styles from '../styles/styles';

export default function CarCard({car}) {
  return (
    <View style={styles.card}>
      <Image
        source={{ uri: car.foto || 'https://media.istockphoto.com/id/1478431022/es/foto/coches-en-venta-de-stock-mucha-fila.jpg?s=1024x1024&w=is&k=20&c=pEuKJ0zJ1ysBuae7SOhae1dWREm8fSd9y7tnKMu3Qmo=' }}
        style={styles.image}
      />
      <View style={styles.info}>
        <Text style={styles.infoText}>PLaca: {car.placa || 'Desconocida'}</Text>
        <Text style={styles.infoText}>Conductor: {car.conductor || 'N/A'}</Text>
      </View>
    </View>
  );
}
