import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';
import styles from '../styles/styles';

export default function LoginScreen({ setToken, setCarros }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const login = async () => {
    try {
      const response = await fetch('https://carros-electricos.wiremockapi.cloud/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (response.ok && data.token) {
        setToken(data.token);
        fetchCarros(data.token);
      } else {
        Alert.alert('Error', 'Credenciales incorrectas');
      }
    } catch (err) {
      Alert.alert('Error', 'No se pudo conectar al servidor');
    }
  };

  const fetchCarros = async (token) => {
    try {
      const response = await fetch('https://carros-electricos.wiremockapi.cloud/carros', {
        headers: { Authentication: token },
      });

      const data = await response.json();

      if (response.ok) {
        setCarros(data);
      } else {
        Alert.alert('Error', 'No se pudieron obtener los carros');
      }
    } catch (err) {
      Alert.alert('Error', 'Error al obtener carros');
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.loginBox}>
        <Text style={styles.title}>Sign In</Text>
        <Text style={styles.label}>User Name:</Text>
        <TextInput
          style={styles.input}
          placeholder="johndoe"
          value={username}
          onChangeText={setUsername}
        />
        <Text style={styles.label}>Password:</Text>
        <TextInput
          style={styles.input}
          placeholder="********"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />
        <TouchableOpacity style={styles.button} onPress={login}>
          <Text style={styles.buttonText}>SIGN IN</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
