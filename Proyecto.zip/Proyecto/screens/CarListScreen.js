import React from 'react';
import { View, FlatList, SafeAreaView } from 'react-native';
import CarCard from '../components/CarCard';
import styles from '../styles/styles';

export default function CarListScreen({ carros }) {
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={carros}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => <CarCard car={item} />}
      />
    </SafeAreaView>
  );
}
