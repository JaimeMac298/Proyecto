import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },

  loginBox: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 20,
    borderRadius: 10,
  },
  title: { fontSize: 24, marginBottom: 20, textAlign: 'center' },
  label: { fontWeight: 'bold', marginBottom: 4 },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 8,
    marginBottom: 16,
  },
  button: {
    backgroundColor: '#33AFFF',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: { color: '#fff', fontWeight: 'bold' },

  card: {
    flexDirection: 'row',
    padding: 10,
    marginBottom: 12,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: '#ccc',
    alignItems: 'center',
  },
  image: {
    width: 80,
    height: 80,
    marginRight: 16,
    borderRadius: 10,
    backgroundColor: '#eee',
  },
  info: { flexShrink: 1 },
  infoText: { fontSize: 16, marginBottom: 4 },
});

export default styles;
